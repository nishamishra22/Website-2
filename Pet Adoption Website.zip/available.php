<?php
    session_start();

    if (!isset($_SESSION['username'])){ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
     <title>Tails_Of_The_City</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/adopt.css" rel="stylesheet">

</head><!--/head-->
        
<!--*********************************************START OF NAVIGATION BAR****************************************--> 
<body>
    <nav class="navbar background">
        <ul class="nav-list">
            <div class="logo"><img src="image/logo.png" alt="logo"></div>
            <li><a href="Nisha.html"><b>Home</b></a></li>
                <div class="dropdown">
                    <div class="dropbtn"><b>Services</b></div>
                    <div class="dropdown-content">
                      <a href="available.php"><b>AdoptMe</b></a>
                      <a href="rescue.html"><b>RescueMe</b></a>
                      <a href="donate.html"><b>Donate</b></a>
                      <a href="doc.html"><b>Doctor's Consultation</b></a>
                    </div>
                </div> 
            <li><a href="aboutus.html"><b>About Us</b></a></li>
            <li><a href="contact us.html"><b>Contact Us</b></a></li>
        </ul>
    </nav>   
  
		
    
<!--*********************************************START OF Availables************************************************-->

<section id="tour-packages" class="center wow fadeInDown">
    <div style="font-size:30px; font-family:verdana; font-weight:bold; color: #DC143C; text-align:center;">Available Pets</div>
        <p style="text-align:center; font-family:verdana;"><br></p>

        <div class="container" style="height:500px;">
			<iframe src="availableframe.php" width="100%;" height="455px;" style="border-style:none;"></iframe>

            </div>
        </div>

</section>
<footer class="back">
	    <p class="foot">
             Copyright@2022|Tails_Of_The_City - Online Pet Adoption & Rescue Management System | All Rights Reserved.
	    </p>
</footer>
   


</body>
</html>

<?php 

} else if(isset($_SESSION['username'])) { 

    include('includes/admin.php');

} ?>